package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Admin;
import model.Product;
import model.User;

public class ProductDAOImp implements ObjectDAO {

	@Override
	public List<Product> getAll() {
		List<Product> resultList = new ArrayList<Product>();
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement stmt = conn.prepareStatement("SELECT * FROM sanpham;");
				ResultSet result = stmt.executeQuery()) {
			System.out.println("Connection successful.");
			while (result.next()) {
				String id = result.getString("id");
				String img = result.getString("img");
				String name = result.getString("name");
				double price = result.getDouble("price");
				Product product = new Product(id, img, name, price);
				resultList.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
		}
		System.out.println("Number of products retrieved: " + resultList.size());
		return resultList;
	}

	@Override
	public Product delete(String id) {
		Product product = null;
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preStatement = conn.prepareStatement("DELETE FROM product WHERE id = ?")) {
			preStatement.setString(1, id);
			int rows = preStatement.executeUpdate();
			if (rows > 0) {
				product = new Product(id, product.getImg(), product.getName(), product.getPrice());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return product;
	}

	@Override
	public Product insert(String id, String img, String name, double price) {
		Product newProduct = null;
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preStatement = conn.prepareStatement("INSERT INTO product VALUES(?, ?, ?, ?)")) {
			System.out.println("SQL Statement: " + preStatement.toString());
			preStatement.setString(1, id);
			preStatement.setString(2, img);
			preStatement.setString(3, name);
			preStatement.setDouble(4, price);
			int rows = preStatement.executeUpdate();
			if (rows > 0) {
				newProduct = new Product(id, img, name, price);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return newProduct;
	}

	@Override
	public Product findById(String id) {
	    Product product = null;
	    try (Connection conn = DBConnection.getConnection();
	            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM product WHERE id = ?")) {
	        preparedStatement.setString(1, id);
	        try (ResultSet result = preparedStatement.executeQuery()) {
	            if (result.next()) {
	                String img = result.getString("img");
	                String name = result.getString("name");
	                double price = result.getDouble("price");
	                product = new Product(id, img, name, price);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return product;
	}

	@Override
	public Admin login_admin(String username, String password) {
		Admin admin = null;
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn
						.prepareStatement("SELECT * FROM admin WHERE username = ? AND password = ?")) {
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			try (ResultSet result = preparedStatement.executeQuery()) {
				if (result.next()) {
					admin = new Admin(username, password);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admin;
	}

	@Override
	public User signup(String email, String username, String password) {
		User newUser = null;
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO users VALUES(?, ?, ?)")) {
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, username);
			preparedStatement.setString(3, password);
			int rows = preparedStatement.executeUpdate();
			if (rows > 0) {
				newUser = new User(email, username, password);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return newUser;
	}

	@Override
	public User signin(String username, String password) {
		User user = null;
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn
						.prepareStatement("SELECT username, password FROM users WHERE username = ? AND password = ?")) {
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			try (ResultSet result = preparedStatement.executeQuery()) {
				if (result.next()) {
					user = new User(username, password);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public void updateOTP(String email, int otp) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement preparedStatement = conn
						.prepareStatement("UPDATE users SET otp = ? WHERE email = ?")) {
			preparedStatement.setInt(1, otp);
			preparedStatement.setString(2, email);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void newPass(String username, String newPassword) {
		try (Connection conn = DBConnection.getConnection();
				PreparedStatement updateStatement = conn
						.prepareStatement("UPDATE users SET password=? WHERE username=?")) {
			updateStatement.setString(1, newPassword);
			updateStatement.setString(2, username);
			int rows = updateStatement.executeUpdate();
			if (rows > 0) {
				System.out.println("Password updated successfully.");
			} else {
				System.out.println("User not found or no changes were made.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
