package DAO;

import java.util.List;

import model.Admin;
import model.Product;
import model.User;

public interface ObjectDAO {

	List<Product> getAll();

	Product insert(String id, String img, String name, double price);
	
	Product delete(String id);

	Product findById(String id);

	Admin login_admin(String username, String password);

	User signup(String email, String username, String password);

	User signin(String username, String password);
	
	void updateOTP(String email, int otp);
	
	void newPass(String username, String newPassword);
	    
}
