package Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.Admin;
import model.User;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	req.setCharacterEncoding("UTF-8");
        try {
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            ObjectDAO productDAO = FactoryProduct.getInstance().getProductDAO();
            User users = productDAO.signin(username, password);
            Admin admin = productDAO.login_admin(username, password);
            if (users != null) {
                // User login successful
                req.getSession().setAttribute("user", users);
                System.out.println("User login successful.");
//                RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
//                rd.forward(req, resp);
                resp.sendRedirect("index.jsp");
            } else if (admin != null) {
                // Admin login successful
                req.getSession().setAttribute("admin", admin);
                System.out.println("Admin login successful.");
                resp.sendRedirect("admin.jsp");
            } else {
                // Login failed
                HttpSession session = req.getSession();
                System.out.println("Login fail.");
                session.setAttribute("error", "Invalid username or password");
                RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
                rd.forward(req, resp);
            }

        } catch (Exception e) {
            e.printStackTrace();
            req.getSession().setAttribute("error", "An error occurred during login");
            RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
            rd.forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
