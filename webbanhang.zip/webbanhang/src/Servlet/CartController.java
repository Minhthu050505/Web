package Servlet;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.Product;
@WebServlet("/cart")
public class CartController extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse resp) {
		try {
			ObjectDAO objectDAO = FactoryProduct.getInstance().getProductDAO();
			List<Product> product = objectDAO.getAll();
			req.getSession().setAttribute("product", product);
			RequestDispatcher rd = req.getRequestDispatcher("/cart.jsp");
			rd.forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
