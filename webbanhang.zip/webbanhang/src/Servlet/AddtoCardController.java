package Servlet;

import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.Item;
import model.Oder;
import model.Product;

@WebServlet(urlPatterns = { "/addtoCard" })
public class AddtoCardController extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
        try {
            int quantity = 1;
            String id = req.getParameter("id");
            ObjectDAO objDAO = FactoryProduct.getInstance().getProductDAO();
            if (id != null) {
                Product product = objDAO.findById(id);
                if (product != null) {
                    if (req.getParameter("quantity") != null) {
                        quantity = Integer.parseInt(req.getParameter("quantity"));
                    }
                    HttpSession session = req.getSession();
                    // Check if the shopping cart exists in the session
                    Oder oder = (Oder) session.getAttribute("oder");
                    if (oder == null) {
                        oder = new Oder();
                    }
                    List<Item> items = oder.getItems();
                    boolean check = false;
                    for (Item item : items) {
                        if (item.getProduct().getId() == product.getId()) {
                            item.setQuantity(item.getQuantity() + quantity);
                            check = true;
                        }
                    }
                    // Use == for comparison
                    if (check == false) {
                        Item item = new Item();
                        item.setQuantity(quantity);
                        item.setProduct(product);
                        item.setPrice(product.getPrice());
                        items.add(item);
                    }
                    session.setAttribute("oder", oder);
                }
                resp.sendRedirect("cart.jsp");
            } else {
                resp.sendRedirect("cart.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
