package Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.User;

@WebServlet("/signupServlet")
public class SignUpServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String username = req.getParameter("username");
			String email = req.getParameter("email");
			String password = req.getParameter("password");
			String confirmPassword = req.getParameter("confirm-password");
			if (username != null && !username.isEmpty() && password.equals(confirmPassword)) {
				// có thể trùng email nhưng phải khác username
				ObjectDAO productDAO = FactoryProduct.getInstance().getProductDAO();
				User newUser = productDAO.signup(email, username, password);
				if (newUser != null) {
					HttpSession session = req.getSession();
					session.setAttribute("email", email);
					session.setAttribute("username", username);
					System.out.println("Username set in session: " + username);
					// Đăng ký thành công, chuyển hướng đến trang đăng nhập
					resp.sendRedirect("/login.jsp");
					/*
					 * RequestDispatcher rd = req.getRequestDispatcher("login.jsp"); rd.forward(req,
					 * resp);
					 */
				} else {
					// Đăng ký không thành công, chuyển hướng lại trang đăng ký với thông báo lỗi
					req.setAttribute("error", "Đăng ký không thành công. Vui lòng thử lại sau.");
					RequestDispatcher rd = req.getRequestDispatcher("sign_up.jsp");
					rd.forward(req, resp);
				}
			} else {
				// Mật khẩu không khớp, chuyển hướng lại trang đăng ký với thông báo lỗi
				req.setAttribute("error", "Mật khẩu không khớp. Vui lòng nhập lại.");
				RequestDispatcher rd = req.getRequestDispatcher("sign_up.jsp");
				rd.forward(req, resp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
}